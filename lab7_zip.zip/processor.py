"""Bus transit fare utilities hardened against malformed external input."""

import math


def parse_transit_corridor(corridor_code):
    """Parse a corridor in ORIGIN-DESTINATION-ZONES format."""
    if not isinstance(corridor_code, str):
        raise TypeError("corridor_code must be a string")

    parts = corridor_code.strip().split("-")
    if len(parts) != 3:
        raise ValueError("corridor must contain exactly ORIGIN-DESTINATION-ZONES")

    orig, dest, zones_str = (part.strip() for part in parts)
    if not orig or not dest:
        raise ValueError("origin and destination cannot be empty")
    if not orig.isalpha() or not dest.isalpha():
        raise ValueError("origin and destination must contain letters only")
    if not zones_str.isdigit():
        raise ValueError("zones must be a positive integer")

    zones = int(zones_str)
    if zones <= 0:
        raise ValueError("zones must be greater than zero")

    base_fare = 2.50 + (zones * 0.75)
    return f"Route {orig.upper()}->{dest.upper()}: {zones} Zones, Fare ${base_fare:.2f}"


def lookup_concession_discount(category_name):
    """Return the fare multiplier for a supported concession category."""
    if not isinstance(category_name, str):
        raise TypeError("category_name must be a string")

    category = category_name.strip().upper()
    discounts = {
        "STANDARD": 1.00,
        "STUDENT": 0.50,
        "SENIOR": 0.35,
        "MILITARY": 0.20,
        "CHILD": 0.00,
    }
    if category not in discounts:
        raise ValueError(f"unknown concession category: {category!r}")
    return discounts[category]


def compute_passenger_density(occupancy_ratio_str):
    """Compute passengers per kilometre from a PASSENGERS/KM string."""
    if not isinstance(occupancy_ratio_str, str):
        raise TypeError("occupancy_ratio_str must be a string")

    parts = occupancy_ratio_str.strip().split("/")
    if len(parts) != 2:
        raise ValueError("occupancy ratio must have the form PASSENGERS/KM")

    passengers_str, km_str = (part.strip() for part in parts)
    if not passengers_str or not km_str:
        raise ValueError("passengers and kilometres are required")

    try:
        passengers = float(passengers_str)
        km = float(km_str)
    except ValueError as exc:
        raise ValueError("passengers and kilometres must be numeric") from exc

    if not math.isfinite(passengers) or not math.isfinite(km):
        raise ValueError("passengers and kilometres must be finite numbers")
    if passengers < 0:
        raise ValueError("passengers cannot be negative")
    if km <= 0:
        raise ValueError("kilometres must be greater than zero")

    density = passengers / km
    return round(density, 2)


def main():
    print("==== Running parse_transit_corridor ====")
    c_input = input("Enter corridor (e.g. DT-UP-3): ")
    try:
        print(parse_transit_corridor(c_input))
    except (TypeError, ValueError) as exc:
        print("Invalid corridor:", exc)

    print("\n==== Running lookup_concession_discount ====")
    cat_input = input("Enter concession category (e.g. STUDENT, SENIOR): ")
    try:
        print("Multiplier:", lookup_concession_discount(cat_input))
    except (TypeError, ValueError) as exc:
        print("Invalid concession category:", exc)

    print("\n==== Running compute_passenger_density ====")
    d_input = input("Enter passengers/km (e.g. 50/10.0): ")
    try:
        print("Density:", compute_passenger_density(d_input))
    except (TypeError, ValueError) as exc:
        print("Invalid passenger density:", exc)


if __name__ == "__main__":
    main()
