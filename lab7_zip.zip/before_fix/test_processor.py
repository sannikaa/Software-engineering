"""Property-based tests used to expose validation bugs in the starter code."""

import pytest
from hypothesis import given, strategies as st
from processor import parse_transit_corridor, lookup_concession_discount, compute_passenger_density


@given(st.text() | st.none())
def test_parse_transit_corridor_rejects_bad_input(s):
    with pytest.raises((TypeError, ValueError)):
        parse_transit_corridor(s)


@given(st.text() | st.none())
def test_lookup_concession_discount_rejects_bad_input(s):
    with pytest.raises((TypeError, ValueError)):
        lookup_concession_discount(s)


@given(st.text() | st.none())
def test_compute_passenger_density_rejects_bad_input(s):
    with pytest.raises((TypeError, ValueError)):
        compute_passenger_density(s)


@pytest.mark.parametrize("ratio", ["15/0", "20/-5", "-3/4", "nan/2", "inf/2"])
def test_density_rejects_invalid_values(ratio):
    with pytest.raises((TypeError, ValueError)):
        compute_passenger_density(ratio)
