"""Property-based fuzz tests for the bus transit fare processor."""

import pytest
from hypothesis import given, strategies as st

from processor import (
    compute_passenger_density,
    lookup_concession_discount,
    parse_transit_corridor,
)


@given(st.text() | st.none())
def test_parse_transit_corridor_no_crash(s):
    try:
        parse_transit_corridor(s)
    except (TypeError, ValueError):
        # Invalid input should be rejected cleanly, not crash unexpectedly.
        pass


@given(st.text() | st.none())
def test_lookup_concession_discount_safe(s):
    try:
        lookup_concession_discount(s)
    except (TypeError, ValueError):
        # Unknown categories and non-string values should be rejected cleanly.
        pass


@given(st.text() | st.none())
def test_compute_passenger_density_safe(s):
    try:
        compute_passenger_density(s)
    except (TypeError, ValueError):
        # Malformed ratios and invalid numbers should be rejected cleanly.
        pass


# Focused properties ensure valid inputs retain their expected behaviour.
@given(
    st.text(alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZ", min_size=1, max_size=5),
    st.text(alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZ", min_size=1, max_size=5),
    st.integers(min_value=1, max_value=100),
)
def test_valid_corridor_format(origin, destination, zones):
    result = parse_transit_corridor(f"{origin}-{destination}-{zones}")
    assert result.startswith(f"Route {origin}->{destination}: {zones} Zones")


@given(st.sampled_from(["STANDARD", "STUDENT", "SENIOR", "MILITARY", "CHILD"]))
def test_known_concession_categories_return_multiplier(category):
    assert 0.0 <= lookup_concession_discount(category) <= 1.0


@given(
    st.floats(min_value=0, max_value=1_000_000, allow_nan=False, allow_infinity=False),
    st.floats(min_value=0.01, max_value=1_000_000, allow_nan=False, allow_infinity=False),
)
def test_valid_density_is_non_negative(passengers, kilometres):
    assert compute_passenger_density(f"{passengers}/{kilometres}") >= 0


@pytest.mark.parametrize("bad_input", ["", "A-B", "A-B-0", "A-B-x", "A-B-2-extra", None])
def test_invalid_corridors_rejected(bad_input):
    with pytest.raises((TypeError, ValueError)):
        parse_transit_corridor(bad_input)


@pytest.mark.parametrize("bad_input", ["", "GUEST", "STUDENT1", None])
def test_invalid_concessions_rejected(bad_input):
    with pytest.raises((TypeError, ValueError)):
        lookup_concession_discount(bad_input)


@pytest.mark.parametrize("bad_input", ["", "10", "10/0", "10/-2", "-1/2", "nan/2", "inf/2", None])
def test_invalid_density_rejected(bad_input):
    with pytest.raises((TypeError, ValueError)):
        compute_passenger_density(bad_input)
