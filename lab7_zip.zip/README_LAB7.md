# Lab 7 – Bus Transit Fare (Fuzz Testing)

## Files
- `processor.py` – hardened implementation.
- `test_processor.py` – Hypothesis fuzz tests and focused regression/property tests.
- `processor_buggy.py` – original starter version, retained for reference only.
- `test_processor_before_fix.py` – strict tests to run against the buggy starter if you need to reproduce the failing stage.

## Local setup
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install hypothesis pytest
```

## Run the fixed application
```bash
python processor.py
```
Example inputs:
- Corridor: `DT-UP-3`
- Category: `STUDENT`
- Density: `50/10`

Expected outputs include `Route DT->UP: 3 Zones, Fare $4.75`, multiplier `0.5`, and density `5.0`.

## Run tests
```bash
python -m pytest -v test_processor.py
```

## Reproduce the failing stage (before fix)
The original starter file is `before_fix/processor.py`. Run the strict fuzz tests inside that directory:
```bash
cd before_fix
python -m pytest -v test_processor.py
```
These tests require invalid inputs to be rejected using the specified validation exceptions; the starter code does not consistently do that (for example it can raise `AttributeError`, `KeyError`, or `ZeroDivisionError`).

## Screenshot evidence required by handout
1. Run the original application in `before_fix` and capture terminal output.
2. Run `python -m pytest -v test_processor.py` in `before_fix` and capture the failing tests.
3. Run fixed `processor.py` with the example inputs above and capture output.
4. Run `python -m pytest -v test_processor.py` in the main Lab 7 folder and capture the passing result.
5. Combine the screenshots into a PDF named `Lab7_FuzzTesting_SanikaPatil.pdf`.

Do not submit generated or fabricated screenshots. Capture the actual output from your own Mac terminal.
